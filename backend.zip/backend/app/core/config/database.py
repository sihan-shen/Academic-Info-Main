"""
数据库配置管理模块
提供数据库连接和迁移相关的配置
"""

from typing import Dict, Any
from pydantic_settings import BaseSettings
from functools import lru_cache


class DatabaseSettings(BaseSettings):
    """数据库配置设置"""
    # MongoDB配置
    MONGO_URI: str
    DB_NAME: str = "teacher_query"
    
    # Alembic迁移配置
    ALEMBIC_CONFIG_PATH: str = "alembic.ini"
    ENABLE_AUTO_MIGRATION: bool = True
    
    class Config:
        env_file = ".env"
        case_sensitive = True


@lru_cache()
def get_database_settings() -> DatabaseSettings:
    """获取数据库配置（单例模式）"""
    return DatabaseSettings()


def get_mongo_connection_params() -> Dict[str, Any]:
    """获取MongoDB连接参数"""
    settings = get_database_settings()
    return {
        "mongo_uri": settings.MONGO_URI,
        "db_name": settings.DB_NAME
    }